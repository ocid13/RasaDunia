import 'regenerator-runtime';
import './styles/style.css';
import './script/component/app-bar';
import main from './script/view/main';

document.addEventListener('DOMContentLoaded', main);
